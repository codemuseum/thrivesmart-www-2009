require File.dirname(__FILE__) + '/../test_helper'
require 'stories_controller'

# Re-raise errors caught by the controller.
class StoriesController; def rescue_action(e) raise e end; end

class StoriesControllerTest < Test::Unit::TestCase
  fixtures :stories

  def setup
    @controller = StoriesController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
  end

  def test_should_get_index
    get :index
    assert_response :success
    assert assigns(:stories)
  end

  def test_should_get_new
    get :new
    assert_response :success
  end
  
  def test_should_create_stories
    old_count = Stories.count
    post :create, :stories => { }
    assert_equal old_count+1, Stories.count
    
    assert_redirected_to stories_path(assigns(:stories))
  end

  def test_should_show_stories
    get :show, :id => 1
    assert_response :success
  end

  def test_should_get_edit
    get :edit, :id => 1
    assert_response :success
  end
  
  def test_should_update_stories
    put :update, :id => 1, :stories => { }
    assert_redirected_to stories_path(assigns(:stories))
  end
  
  def test_should_destroy_stories
    old_count = Stories.count
    delete :destroy, :id => 1
    assert_equal old_count-1, Stories.count
    
    assert_redirected_to stories_path
  end
end
