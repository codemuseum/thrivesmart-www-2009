class CreateStories < ActiveRecord::Migration
  def self.up
    create_table :stories do |t|
      t.column :name, :string
      t.column :short_description, :string
      t.column :long_description, :text
    end
  end

  def self.down
    drop_table :stories
  end
end
