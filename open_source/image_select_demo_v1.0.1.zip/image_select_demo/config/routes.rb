ActionController::Routing::Routes.draw do |map|
  map.resources :stories
  map.resources :my_images, :controller => 'images'


  # Install the default route as the lowest priority.
  map.connect ':controller/:action/:id.:format'
  map.connect ':controller/:action/:id'
end
