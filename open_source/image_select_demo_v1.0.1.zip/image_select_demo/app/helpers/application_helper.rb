# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper
  def js_open
    '<script type="text/javascript">//<![CDATA[' + "\n"
  end
  
  def js_close
    "\n" + '//]]>' + "</script>"
  end
  def use_tinymce 
    string = <<END_OF_STRING
    tinyMCE.init({
    	mode : "textareas",
    	editor_selector : "tiny_mce",
    	theme : "advanced",
    	plugins : "inlinepopups,ts_advimage,advlink,emotions,iespell,zoom,searchreplace,fullscreen,visualchars,youtube",
    	theme_advanced_buttons1 : "undo,redo,removeformat,|,formatselect,|,bold,italic,underline,strikethrough,sub,sup,|,outdent,indent,bullist,numlist,hr,backcolor,|,link,unlink,charmap,emotions,ts_image,youtube,iespell,|,search,replace,|,cleanup,code,fullscreen,help",
    	theme_advanced_buttons2 : "",
    	theme_advanced_buttons3 : "",
    	theme_advanced_toolbar_location : "top",
    	theme_advanced_toolbar_align : "left",
    	theme_advanced_path_location : "bottom",
    	theme_advanced_blockformats : "p,h1,h2,h3,h4,blockquote",
    	gecko_spellcheck : true,
    	extended_valid_elements : "a[name|href|target|title|onclick],img[class|src|style|border=0|alt|title|hspace|vspace|width|height|align|onmouseover|onmouseout|name],hr[class|width|size|noshade],span[class|align|style],font[]",
    	theme_advanced_resizing : true,
    	theme_advanced_resize_horizontal : false
    });
END_OF_STRING

    js_open + string + js_close
  end
end
