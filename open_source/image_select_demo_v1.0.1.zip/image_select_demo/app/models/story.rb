class Story < ActiveRecord::Base
  has_many :images
  
  validates_presence_of :name
  validates_presence_of :short_description
  validates_presence_of :long_description
  
end
