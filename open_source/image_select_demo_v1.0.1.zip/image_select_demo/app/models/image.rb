class Image < ActiveRecord::Base
  belongs_to :story
  
  has_attachment :content_type => :image,
                 :storage => :file_system,
                 :max_size => 5.megabytes,
                 :resize_to => '800x600>',
                 :processor => :Rmagick,
                 :thumbnails => { :thumb => '100x100>' }
  validates_as_attachment
  
end
